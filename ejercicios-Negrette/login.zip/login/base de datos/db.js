const mysql=require('mysql');

const conexion=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'fat'
})

conexion.connect((error)=>{
    if(error){
        throw error;
    }else{
        console.log('CONEXION LISTA')
    }
})

module.exports=conexion;