const express=require('express');
const router=express.Router();
const conexion=require('./base de datos/db');


router.get('/',(req,res)=>{
   
    conexion.query('SELECT personas.id, personas.nombre, personas.apellido, personas.usuario, personas.pass FROM personas',(error,results)=>{;
    if(error){
        throw error;
    }else{
        res.render('/',{results:results});
    }
})
    
});





router.get('/registro',(req,res)=>{
   
    conexion.query('SELECT personas.id, personas.nombre, personas.apellido, personas.usuario, personas.pass FROM personas',(error,results)=>{;
    if(error){
        throw error;
    }else{
        res.render('registro',{results:results});
    }
})
    
});


const crud=require('./controllers/crud.js');
router.post('/save_usuario',crud.save_usuario);


module.exports=router;
