const conexion=require('../base de datos/db');


//para guardar materias
exports.save_usuario=(req,res)=>{
    
    const nombre=req.body.nombre;
    const apellido=req.body.apellido;
    const usuario=req.body.usuario;
    const pass=req.body.final;
    
    conexion.query('INSERT INTO personas SET ?',{nombre:nombre,apellido:apellido,usuario:usuario,pass:final},(error,results)=>{
        if(error){
            console.log(error);

        }else{
            res.redirect('/');
        }
    })
    
};