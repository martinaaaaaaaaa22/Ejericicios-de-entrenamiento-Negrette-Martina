const express = require('express');
const app = express();
app.set('view engine','ejs');
app.use(express.urlencoded({extended:false}));
app.use(express.json());

const dotenv = require('dotenv');
dotenv.config({ path: './env/.env'});

app.use('/resources',express.static('public'));
app.use('/resources', express.static(__dirname + '/public'));

const session = require('express-session');
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

const connection = require('./base de datos/db');

app.get('/',(req, res)=>{
    res.render('index');
})

app.get('/login',(req, res)=>{
    res.render('login');
})

app.get('/registro',(req, res)=>{
    res.render('registro');
})

app.get('/hola',(req, res)=>{
    res.render('hola');
})


////////////////////////////////////LOGIN/////////////////////////////////////////////////

app.post('/iniciar',function(req,res){
    const usuario=req.body.usuario;
    const pass=req.body.pass;
    
    if(usuario && pass){
        const resultado=connection.query('SELECT * FROM personas WHERE usuario= ? AND pass=? ',[usuario,pass],function(error, results, fields) {
			// If there is an issue with the query, output the error
			if (error) throw error;
			// If the account exists
			if (results.length > 0) {
				// Authenticate the user
				req.session.loggedin = true;
				req.session.usuario = usuario;
				// Redirect to home page
				res.redirect('/hola');
			} else {
				res.send('USUARIO O CONTRASEÑA INCORRECTAS');
			}			
			res.end();
		});
	} else {
		res.send('INGRESE SU USUARIO O CONTRASEÑA');
		res.end();
	}
});


/////////////////////////////////REGISTRO/////////////////////////////////////////////////////
app.post('/save_usuario',function(req,res){
    const nombre=req.body.nombre;
    const apellido=req.body.apellido;
    const usuario=req.body.usuario;
    const pass=req.body.pass;

    const abecedario = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
    const key =        ["z","y","x","w","v","u","t","s","r","q","p","o","ñ","n","m","l","k","j","i","h","g","f","e","d","c","b","a","Z","Y","X","W","V","U","T","S","R","Q","P","O","Ñ","N","M","L","K","J","I","H","G","F","E","D","C","B","A"];


    const mensajeCifrado = '';
    const salteos=2
    for ( i=0; i<pass.length; i++) {
        letra = pass[i];
        if(/^[a-z A-Z]+$/.test(letra)){
            posicion = abecedario.indexOf(letra);
            final=mensajeCifrado + key[posicion + salteos];
            
        }
    
    }
   

    const resultado=connection.query('INSERT INTO personas SET ?  ',{nombre:nombre,apellido:apellido,usuario:usuario,pass:final},function(error, results, fields) {
        
        if(error){
            console.log(error);

        }else{
            res.redirect('/hola');
        }
    })
});












///////////////////////////////////////////////////////////////////////


app.listen(3000, ()=>{
    console.log('SERVER corriendo en http://localhost:3000');
});
